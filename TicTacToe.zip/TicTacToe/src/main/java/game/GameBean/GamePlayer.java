package game.GameBean;

public interface GamePlayer {

}
